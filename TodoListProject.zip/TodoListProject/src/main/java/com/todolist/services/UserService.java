
package com.todolist.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.todolist.dao.UserDao;
import com.todolist.models.User;

@Service
public class UserService {

	@Autowired
	private UserDao userDao;

	public User add(User user) {
		return userDao.save(user);

	}

	public boolean emailExist(String email) {
		if (userDao.getUserByEmail(email) != null)
			return true;
		else
			return false;
	}

}
