package com.todolist.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.todolist.dao.TaskDao;
import com.todolist.models.Task;

@Service
public class TaskService {

	@Autowired
	private TaskDao taskDao;

	public Task add(Task task) {
		return taskDao.save(task);
	}

	public Task getById(Integer id) {
		return taskDao.getById(id);
	}

	public Task edit(Task task) {
		return taskDao.save(task);
	}

	public void delete(Integer id) {

		taskDao.deleteById(id);

	}
}
