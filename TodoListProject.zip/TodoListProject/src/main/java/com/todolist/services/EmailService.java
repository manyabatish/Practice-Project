package com.todolist.services;

public interface EmailService {

	public void sendMail(String toUser, String body, String subject );

}
