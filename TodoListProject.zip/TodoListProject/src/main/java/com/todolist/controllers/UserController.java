package com.todolist.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.todolist.exceptions.EmailExistsException;
import com.todolist.models.User;
import com.todolist.services.UserService;

@RestController
public class UserController {

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private UserService userService;

	@PostMapping("/signUp")
	public User registerNewUserAccount(@RequestBody User userDetails) throws EmailExistsException {
		if (userService.emailExist(userDetails.getEmail())) {
			throw new EmailExistsException("There is an account with that email adress:" + userDetails.getEmail());
		}
		else {
		User user = new User();
		user.setEmail(userDetails.getEmail());
		user.setFirstName(userDetails.getFirstName());
		user.setLastName(userDetails.getLastName());

		user.setPassword(passwordEncoder.encode(userDetails.getPassword()));
		
		System.out.println(user);
		return userService.add(user);
		}
	}

}
