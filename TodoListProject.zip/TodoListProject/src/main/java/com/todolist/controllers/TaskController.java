package com.todolist.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.todolist.models.Task;
import com.todolist.services.TaskService;

@RestController
public class TaskController {

	@Autowired
	private TaskService taskService;

	@PostMapping("/addTask")
	public Task addTask(@RequestBody Task task) {
		return taskService.add(task);
	}

	@PutMapping("/editTask")
	public Task editTask(@RequestBody Task task) {
		return taskService.edit(task);
	}

	@DeleteMapping("/deleteTask/{id}")
	public void deleteTask(@PathVariable("id") Integer id) {
		taskService.delete(id);
	}

	@GetMapping("/getTask/{id}")
	public Task getTaskById(@PathVariable("id") Integer id) {
		return taskService.getById(id);
	}

}
