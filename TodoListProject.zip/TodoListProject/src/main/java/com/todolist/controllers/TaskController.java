package com.todolist.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.todolist.models.Task;
import com.todolist.servicesimpl.TaskServiceImpl;

@RestController
@CrossOrigin
public class TaskController {

    @Autowired
    private TaskServiceImpl taskServiceImpl;

    /**
     * @param authentication
     * @param task
     * @return created task
     */
    @PostMapping("/create-task")
    public Task addTask(Authentication authentication, @RequestBody Task task) {
        task.setUsername(authentication.getName());
        return taskServiceImpl.add(task);
    }

    /**
     * @param task
     * @return modified task
     */
    @PutMapping("/edit-task")
    public Task editTask(@RequestBody Task task) {
        return taskServiceImpl.edit(task);
    }

    /**
     * @param id
     */
    @DeleteMapping("/delete-task/{id}")
    public void deleteTask(@PathVariable("id") Integer id) {
        taskServiceImpl.delete(id);
    }

    /**
     * @param id
     * @return fetched task by id
     */
    @GetMapping("/get-task/{id}")
    public Task getTaskById(@PathVariable("id") Integer id) {
        return taskServiceImpl.getById(id);
    }

    /**
     * @param authentication
     * @return tasks present under logged in user
     */
    @GetMapping("/tasks-list")
    public List < Task > getTasksByUser(Authentication authentication) {
        return taskServiceImpl.findByUsername(authentication.getName());
    }

    /**
     * @return all tasks present in DB
     */
    @GetMapping("/tasks")
    public List < Task > getTasks() {
        return taskServiceImpl.getTasks();
    }


}